import './App.css'
import { useEffect, useState } from "react";
function App() {

  const [message, setMessage] = useState("");

  useEffect(() => {
    fetch("http://localhost:5000/api")
      .then((response) => response.json())
      .then((data) => setMessage(data.message))
      .catch((error) => console.error("API error:", error));

  }, []);

  return (
    <div className="website">
      <p>{message}</p>
      <nav className="navbar">
        <h2>TechWorld</h2>
        <div className="nav-links">
          <a href="#home">Home</a>
          <a href="#about">About</a>
          <a href="#services">Services</a>
          <a href="#contact">Contact</a>
        </div>
      </nav>

      <section className="hero" id="home">
        <div className="hero-content">
          <p className="tagline">WELCOME TO TECHWORLD</p>
          <h1>Build Your Future<br />With Technology</h1>
          <p>
            Learn HTML, CSS and JavaScript by creating real-world
            projects. Improve your skills and turn your ideas into reality.
          </p>
          <p className="api-message">{message}</p>
          <a href="#about" className="hero-button">Explore Now →</a>
        </div>
      </section>

      <section className="about" id="about">
        <h2>Learn. Create. Grow.</h2>
        <p>
          TechWorld helps beginners explore web development and
          build beautiful websites step by step.
        </p>
      </section>

      <section className="services" id="services">
        <h2>What You Will Learn</h2>
        <div className="service-cards">
          <div className="service-card">
            <h3>🌐 HTML</h3>
            <p>Create the structure of your website.</p>
          </div>
          <div className="service-card">
            <h3>🎨 CSS</h3>
            <p>Design beautiful and responsive pages.</p>
          </div>
          <div className="service-card">
            <h3>⚡ JavaScript</h3>
            <p>Make your website interactive.</p>
          </div>
        </div>
      </section>

      <footer id="contact">
        <h2>Start Building Your Future Today!</h2>
        <p>© 2026 TechWorld | Learn Something New Every Day</p>
      </footer>
    </div>
  )
}

export default App
